package com.example.data

import kotlinx.coroutines.flow.Flow

class AppRepository(private val appDao: AppDao) {

    val allProducts: Flow<List<Product>> = appDao.getAllProducts()
    val allCartItems: Flow<List<CartItem>> = appDao.getAllCartItems()
    val allOrders: Flow<List<Order>> = appDao.getAllOrders()

    suspend fun getProductById(id: Int): Product? {
        return appDao.getProductById(id)
    }

    suspend fun insertProduct(product: Product): Long {
        return appDao.insertProduct(product)
    }

    suspend fun updateProduct(product: Product) {
        appDao.updateProduct(product)
    }

    suspend fun deleteProduct(product: Product) {
        appDao.deleteProduct(product)
    }

    suspend fun deleteProductById(id: Int) {
        appDao.deleteProductById(id)
    }

    suspend fun insertCartItem(cartItem: CartItem) {
        appDao.insertCartItem(cartItem)
    }

    suspend fun updateCartItem(cartItem: CartItem) {
        appDao.updateCartItem(cartItem)
    }

    suspend fun deleteCartItem(cartItem: CartItem) {
        appDao.deleteCartItem(cartItem)
    }

    suspend fun deleteCartItemByProductId(productId: Int) {
        appDao.deleteCartItemByProductId(productId)
    }

    suspend fun clearCart() {
        appDao.clearCart()
    }

    suspend fun insertOrder(order: Order) {
        appDao.insertOrder(order)
    }
}

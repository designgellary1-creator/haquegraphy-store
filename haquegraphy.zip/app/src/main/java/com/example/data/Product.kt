package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val description: String,
    val category: String, // "PLP", "PSD", "AI", "Template"
    val price: Double, // in USD, or we can deal in BDT/INR
    val imageUri: String, // String reference or URL
    val previewLink: String, // Link of product preview
    val downloadLink: String, // Fake/Real file download link
    val rating: Float = 4.5f,
    val popularity: Int = 0,
    val isNewArrival: Boolean = false,
    val isFeatured: Boolean = false
)

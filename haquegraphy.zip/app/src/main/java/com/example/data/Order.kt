package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "orders")
data class Order(
    @PrimaryKey val id: String, // e.g. "HQ-10291"
    val customerName: String,
    val customerEmail: String,
    val customerPhone: String,
    val paymentMethod: String, // bKash, Nagad, Rocket, UPI, Card, COD
    val paymentTxnId: String, // Transaction ID
    val amountPaid: Double,
    val orderTime: Long = System.currentTimeMillis(),
    val productIds: String, // Comma separated product IDs
    val productTitles: String, // Comma separated product titles for easy preview
    val status: String = "Completed" // "Completed", "Pending"
)

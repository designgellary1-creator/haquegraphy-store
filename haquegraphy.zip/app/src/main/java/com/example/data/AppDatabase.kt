package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [Product::class, CartItem::class, Order::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {

    abstract fun appDao(): AppDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "haquegraphy_db"
                )
                .addCallback(AppDatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class AppDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {

        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateDatabase(database.appDao())
                }
            }
        }

        suspend fun populateDatabase(dao: AppDao) {
            // Delete all products first (ensure starting clean)
            // Then insert high-quality initial products
            val initialProducts = listOf(
                Product(
                    title = "Premium Eid Mubarak Poster PLP",
                    description = "A professional and eye-catching PixelLab project file for Eid-ul-Fitr & Eid-ul-Adha social media greeting posters. Fully customizable layers, premium typography, and pre-arranged Bengali greeting texts. Ready to render in high quality.",
                    category = "PLP",
                    price = 4.99,
                    imageUri = "img_eid_mubarak_plp",
                    previewLink = "https://images.unsplash.com/photo-1564507004663-b6dfb3c824d5?q=80&w=800", // backup or preview
                    downloadLink = "https://drive.google.com/uc?export=download&id=eid_mubarak_plp_sample_id",
                    rating = 4.9f,
                    popularity = 95,
                    isNewArrival = true,
                    isFeatured = true
                ),
                Product(
                    title = "Waz Mahfil Grand Banner PLP",
                    description = "Authentic Islamic Waz Mahfil program backdrop banner designed in PixelLab. High resolution (300 DPI layout equivalent), includes geometric patterns, traditional Islamic domes backdrop, and easy text placeholders for speakers, place, and dates.",
                    category = "PLP",
                    price = 7.50,
                    imageUri = "img_waz_banner_plp",
                    previewLink = "https://images.unsplash.com/photo-1542831371-29b0f74f9713?q=80&w=800",
                    downloadLink = "https://drive.google.com/uc?export=download&id=waz_banner_plp_sample_id",
                    rating = 4.8f,
                    popularity = 89,
                    isNewArrival = false,
                    isFeatured = true
                ),
                Product(
                    title = "Minimalist Business Card Pack PLP",
                    description = "Sleek, creative, and professional modern business card design kit for freelancers and corporate. Built completely inside PixelLab using vectors and modern sans-serif custom fonts. Double-sided layout included.",
                    category = "PLP",
                    price = 2.99,
                    imageUri = "img_business_card_plp",
                    previewLink = "https://images.unsplash.com/photo-1589254065878-42c9da997008?q=80&w=800",
                    downloadLink = "https://drive.google.com/uc?export=download&id=business_card_plp_sample_id",
                    rating = 4.7f,
                    popularity = 74,
                    isNewArrival = true,
                    isFeatured = false
                ),
                Product(
                    title = "Instagram Fashion Banner PSD",
                    description = "High-end corporate & street fashion promo design in Photoshop format. Ideal for digital ads, featuring elegant grid layouts, smart object photo placeholders, premium color grading, and easily modifiable text vectors.",
                    category = "PSD",
                    price = 8.99,
                    imageUri = "img_instagram_fashion_psd",
                    previewLink = "https://images.unsplash.com/photo-1483985988355-763728e1935b?q=80&w=800",
                    downloadLink = "https://drive.google.com/uc?export=download&id=fashion_psd_sample_id",
                    rating = 4.9f,
                    popularity = 98,
                    isNewArrival = true,
                    isFeatured = true
                ),
                Product(
                    title = "Realistic T-Shirt Mockup Standard PSD",
                    description = "A versatile clothing mockup for online merchants. Includes high-resolution apparel folds, configurable shadows, easily updated body colors, and ultra-realistic smart layers to display your branding naturally.",
                    category = "PSD",
                    price = 5.99,
                    imageUri = "img_tshirt_mockup_psd",
                    previewLink = "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?q=80&w=800",
                    downloadLink = "https://drive.google.com/uc?export=download&id=tshirt_mockup_psd_sample_id",
                    rating = 4.6f,
                    popularity = 65,
                    isNewArrival = false,
                    isFeatured = false
                ),
                Product(
                    title = "Vintage Cyberpunk DJ Flyer PSD",
                    description = "Electrifying flyers for night clubs, music festivals, and techno events. Created in Photoshop using energetic retro-neon lights, bold overlay effects, and cybernetic frame patterns. Easily localized fonts.",
                    category = "PSD",
                    price = 9.50,
                    imageUri = "img_cyberpunk_flyer_psd",
                    previewLink = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=800",
                    downloadLink = "https://drive.google.com/uc?export=download&id=cyberpunk_flyer_psd_sample_id",
                    rating = 4.9f,
                    popularity = 92,
                    isNewArrival = true,
                    isFeatured = false
                ),
                Product(
                    title = "Startup Corporate Core Branding AI",
                    description = "Professional vector branding and identity starter templates designed in Adobe Illustrator. Includes customizable vector logos, elegant modern color schemes, brandbook layout patterns, and vector icons.",
                    category = "AI",
                    price = 12.99,
                    imageUri = "img_corporate_branding_ai",
                    previewLink = "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?q=80&w=800",
                    downloadLink = "https://drive.google.com/uc?export=download&id=branding_ai_sample_id",
                    rating = 5.0f,
                    popularity = 110,
                    isNewArrival = false,
                    isFeatured = true
                ),
                Product(
                    title = "Islamic Arabic Calligraphy Borders AI",
                    description = "A vast collections of highly detailed Islamic geometric borders, calligraphy panels, and traditional mandala patterns on vector scales. Ideal for prints, books, and religious greeting materials.",
                    category = "AI",
                    price = 6.80,
                    imageUri = "img_islamic_borders_ai",
                    previewLink = "https://images.unsplash.com/photo-1584551246679-0dac3d27180f?q=80&w=800",
                    downloadLink = "https://drive.google.com/uc?export=download&id=islamic_ai_sample_id",
                    rating = 4.8f,
                    popularity = 80,
                    isNewArrival = true,
                    isFeatured = false
                ),
                Product(
                    title = "Elite ATS-Friendly Resume CV Docx",
                    description = "Clean, highly parsable, applicant-tracking-system safe curriculum vitae resume templates. Includes both Microsoft Word formats (.docx) and direct PDF templates, tailored for tech and creative industries.",
                    category = "Template",
                    price = 3.50,
                    imageUri = "img_resume_cv_docx",
                    previewLink = "https://images.unsplash.com/photo-1586281380349-632531db7ed4?q=80&w=800",
                    downloadLink = "https://drive.google.com/uc?export=download&id=resume_docx_sample_id",
                    rating = 4.9f,
                    popularity = 120,
                    isNewArrival = false,
                    isFeatured = true
                ),
                Product(
                    title = "Cinematic Moody Lightroom Presets Bundle",
                    description = "Professional photo enhancement kits containing 10 premium Lightroom Mobile & Desktop presets (.dng / .xmp). Perfectly fine-tuned for street photography, portrait sessions, and travel blogs to deliver dramatic, consistent looks.",
                    category = "Template",
                    price = 5.00,
                    imageUri = "img_lightroom_presets",
                    previewLink = "https://images.unsplash.com/photo-1542038784456-1ea8e935640e?q=80&w=800",
                    downloadLink = "https://drive.google.com/uc?export=download&id=presets_sample_id",
                    rating = 4.7f,
                    popularity = 85,
                    isNewArrival = true,
                    isFeatured = false
                )
            )

            for (product in initialProducts) {
                dao.insertProduct(product)
            }

            // Let's create an initial dummy purchase order to populate admin dashboard analytics with authentic records!
            val initialOrders = listOf(
                Order(
                    id = "HQ-5091",
                    customerName = "Sadik Al Haque",
                    customerEmail = "sadik@haquegraphy.com",
                    customerPhone = "+8801712345678",
                    paymentMethod = "bKash",
                    paymentTxnId = "BK8X91K20D",
                    amountPaid = 13.98,
                    orderTime = System.currentTimeMillis() - 86400000 * 3, // 3 days ago
                    productIds = "1,3",
                    productTitles = "Premium Eid Mubarak Poster PLP, Minimalist Business Card Pack PLP",
                    status = "Completed"
                ),
                Order(
                    id = "HQ-5092",
                    customerName = "Rahul Sharma",
                    customerEmail = "rahul@gmail.com",
                    customerPhone = "+919876543210",
                    paymentMethod = "UPI",
                    paymentTxnId = "UPI9028163901",
                    amountPaid = 8.99,
                    orderTime = System.currentTimeMillis() - 43200000, // 12 hours ago
                    productIds = "4",
                    productTitles = "Instagram Fashion Banner PSD",
                    status = "Completed"
                )
            )

            for (order in initialOrders) {
                dao.insertOrder(order)
            }
        }
    }
}

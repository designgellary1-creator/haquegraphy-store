package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import com.example.data.Order
import com.example.data.Product
import com.example.ui.*
import com.example.ui.theme.TextMuted

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val isAdminAuth by viewModel.isAdminLoggedIn.collectAsState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        if (!isAdminAuth) {
            AdminLoginView(viewModel)
        } else {
            AdminDashboardView(viewModel)
        }
    }
}

@Composable
fun AdminLoginView(viewModel: MainViewModel) {
    val loginError by viewModel.currentAdminError.collectAsState()
    val isLoading by viewModel.adminLoginLoading.collectAsState()

    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    val isUserSampleMatch = username.trim().equals("HAQUEGRAPHY", ignoreCase = true)
    val isPassSampleMatch = password == "123456"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Upper Shield with Ring Accent
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(90.dp)
                .background(
                    brush = androidx.compose.ui.graphics.Brush.radialGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                            Color.Transparent
                        )
                    ),
                    shape = androidx.compose.foundation.shape.CircleShape
                )
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(64.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant, androidx.compose.foundation.shape.CircleShape)
                    .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f), androidx.compose.foundation.shape.CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.AdminPanelSettings,
                    contentDescription = "Admin Security Shield Logo",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(36.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "HaqueGraphy Gateway",
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp
            ),
            color = MaterialTheme.colorScheme.onBackground
        )

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.padding(top = 4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .background(Color(0xFF10B981), androidx.compose.foundation.shape.CircleShape)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "Secured via Firebase Identity Services",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = com.example.ui.theme.TextMuted
            )
        }

        Spacer(modifier = Modifier.height(28.dp))

        // High Density Admin Control Form
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "ACCESS VALIDATION MANAGER",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp
                    ),
                    color = MaterialTheme.colorScheme.primary
                )

                // Username field
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Admin Username / Email",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
                        )
                        if (username.isNotEmpty()) {
                            Text(
                                text = if (isUserSampleMatch) "Verified local" else "Checking Firebase...",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (isUserSampleMatch) Color(0xFF10B981) else Color(0xFFF59E0B),
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }
                    }
                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it },
                        placeholder = { Text("e.g. HAQUEGRAPHY or admin email", fontSize = 14.sp) },
                        leadingIcon = { Icon(Icons.Default.Person, null, modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_username_input")
                    )
                }

                // Password field
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Root Password",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
                        )
                        if (password.isNotEmpty()) {
                            Text(
                                text = if (isPassSampleMatch) "Local Match" else "Verified Auth",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (isPassSampleMatch) Color(0xFF10B981) else MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }
                    }
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        placeholder = { Text("••••••••", fontSize = 14.sp) },
                        leadingIcon = { Icon(Icons.Default.Lock, null, modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary) },
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = if (passwordVisible) "Hide password" else "Show password",
                                    tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        },
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_password_input")
                    )
                }

                if (loginError != null) {
                    Row(
                        verticalAlignment = Alignment.Top,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.error.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Error,
                            contentDescription = "Error icon",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(16.dp).padding(top = 2.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = loginError!!,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Action Button or Loading Spinner
                if (isLoading) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(
                            color = MaterialTheme.colorScheme.primary,
                            strokeWidth = 3.dp,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                } else {
                    Button(
                        onClick = {
                            viewModel.attemptAdminLogin(username, password)
                        },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("admin_login_submit_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.VpnKey,
                            contentDescription = "Key Icon",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Authenticate Partner Portal",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Black)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Info card explaining credentials
        Card(
            shape = RoundedCornerShape(8.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Info Icon",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "ADMINISTRATOR CREDENTIAL POLICY",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Black),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(
                    text = "Sign in directly with your pre-defined credentials (User: HAQUEGRAPHY / Pass: 123456) or register & connect any authorized developer email via Google Firebase Authentication.",
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        TextButton(
            onClick = { viewModel.navigateTo(Screen.Home) }
        ) {
            Icon(Icons.Default.ArrowBack, null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Back to Storefront", fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun AdminDashboardView(viewModel: MainViewModel) {
    val context = LocalContext.current
    val productsList by viewModel.allProducts.collectAsState()
    val ordersList by viewModel.allOrders.collectAsState()

    // Analytics Math
    val totalRevenue = ordersList.sumOf { it.amountPaid }
    val totalOrdersCount = ordersList.size
    val totalProductsCount = productsList.size

    var activeTab by remember { mutableStateOf("Products") } // "Products" vs "Orders"
    var showAddDialog by remember { mutableStateOf(false) }

    // State for editing or adding products
    val editingProduct by viewModel.editingProduct.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Upper menu toolbar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Control Center",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.secondary
                )
                Text(
                    text = "HaqueGraphy Admin",
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black),
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            Row {
                IconButton(
                    onClick = { viewModel.adminLogout() },
                    modifier = Modifier.testTag("admin_logout_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ExitToApp,
                        contentDescription = "Logout",
                        tint = MaterialTheme.colorScheme.error
                    )
                }

                IconButton(
                    onClick = { viewModel.navigateTo(Screen.Home) }
                ) {
                    Icon(Icons.Default.Home, "Storefront")
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // --- DASHBOARD ANALYTICS PANEL ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            AnalyticsCard(
                title = "Total Revenue",
                value = "$${String.format("%.2f", totalRevenue)}",
                color = MaterialTheme.colorScheme.primary,
                icon = Icons.Default.Check,
                modifier = Modifier.weight(1.1f)
            )

            AnalyticsCard(
                title = "Total Sales",
                value = totalOrdersCount.toString(),
                color = MaterialTheme.colorScheme.secondary,
                icon = Icons.Default.Refresh,
                modifier = Modifier.weight(0.9f)
            )

            AnalyticsCard(
                title = "Products",
                value = totalProductsCount.toString(),
                color = MaterialTheme.colorScheme.tertiary,
                icon = Icons.Default.ShoppingCart,
                modifier = Modifier.weight(0.9f)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Segmented Tabs
        Row(
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(
                onClick = { activeTab = "Products" },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeTab == "Products") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                    contentColor = if (activeTab == "Products") MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                ),
                shape = RoundedCornerShape(12.dp, 0.dp, 0.dp, 12.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
            ) {
                Icon(Icons.Default.List, null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Catalog")
            }

            Button(
                onClick = { activeTab = "Orders" },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeTab == "Orders") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                    contentColor = if (activeTab == "Orders") MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                ),
                shape = RoundedCornerShape(0.dp, 12.dp, 12.dp, 0.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
            ) {
                Icon(Icons.Default.Info, null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Checkout Orders")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Dynamically toggle tab lists
        if (activeTab == "Products") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Catalog Inventory",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )

                Button(
                    onClick = { showAddDialog = true },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                    modifier = Modifier.testTag("admin_add_product_btn")
                ) {
                    Icon(Icons.Default.Add, null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("New Product")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            productsList.forEach { product ->
                AdminProductRow(
                    product = product,
                    onEdit = {
                        viewModel.editingProduct.value = product
                    },
                    onDelete = {
                        viewModel.deleteProduct(product)
                        Toast.makeText(context, "${product.title} deleted!", Toast.LENGTH_SHORT).show()
                    }
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

        } else {
            // Tab Orders
            Text(
                text = "Checkout Order Log",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )

            Spacer(modifier = Modifier.height(12.dp))

            if (ordersList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No checkout orders logged yet.", color = TextMuted)
                }
            } else {
                ordersList.forEach { order ->
                    AdminOrderRow(order = order)
                    Spacer(modifier = Modifier.height(10.dp))
                }
            }
        }

        // Add Product Dialog State
        if (showAddDialog) {
            ProductEditDialog(
                product = null,
                onDismiss = { showAddDialog = false },
                onSave = { p ->
                    viewModel.saveProduct(
                        id = 0,
                        title = p.title,
                        description = p.description,
                        category = p.category,
                        price = p.price,
                        imageUri = p.imageUri,
                        previewLink = p.previewLink,
                        downloadLink = p.downloadLink,
                        popularity = p.popularity,
                        isNewArrival = p.isNewArrival,
                        isFeatured = p.isFeatured
                    )
                    showAddDialog = false
                    Toast.makeText(context, "Added template successfully!", Toast.LENGTH_SHORT).show()
                }
            )
        }

        // Edit Product Dialog State
        if (editingProduct != null) {
            ProductEditDialog(
                product = editingProduct,
                onDismiss = { viewModel.editingProduct.value = null },
                onSave = { p ->
                    viewModel.saveProduct(
                        id = p.id,
                        title = p.title,
                        description = p.description,
                        category = p.category,
                        price = p.price,
                        imageUri = p.imageUri,
                        previewLink = p.previewLink,
                        downloadLink = p.downloadLink,
                        popularity = p.popularity,
                        isNewArrival = p.isNewArrival,
                        isFeatured = p.isFeatured
                    )
                    viewModel.editingProduct.value = null
                    Toast.makeText(context, "Updated template successfully!", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }
}

@Composable
fun AnalyticsCard(
    title: String,
    value: String,
    color: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(12.dp)
        ) {
            Icon(icon, null, tint = color, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.height(12.dp))
            Text(value, fontWeight = FontWeight.Black, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
            Text(title, fontSize = 11.sp, color = TextMuted)
        }
    }
}

@Composable
fun AdminProductRow(
    product: Product,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("admin_product_row_${product.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(MaterialTheme.colorScheme.background, shape = RoundedCornerShape(6.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = product.category,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = product.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text("Price: $${product.price}", fontSize = 12.sp, color = TextMuted)
            }

            IconButton(
                onClick = onEdit,
                modifier = Modifier.testTag("admin_edit_product_btn_${product.id}")
            ) {
                Icon(Icons.Default.Edit, "Edit", tint = MaterialTheme.colorScheme.secondary)
            }

            IconButton(
                onClick = onDelete,
                modifier = Modifier.testTag("admin_delete_product_btn_${product.id}")
            ) {
                Icon(Icons.Default.Delete, "Delete", tint = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
fun AdminOrderRow(order: Order) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Receipt: ${order.id}",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 14.sp
                )

                Box(
                    modifier = Modifier
                        .background(
                            MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(6.dp)
                        )
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "Verified",
                        color = MaterialTheme.colorScheme.secondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Divider(color = MaterialTheme.colorScheme.background, thickness = 1.dp)

            Text("Cutomer: ${order.customerName}", fontWeight = FontWeight.Medium, fontSize = 13.sp)
            Text("Phone: ${order.customerPhone} | Email: ${order.customerEmail}", fontSize = 11.sp, color = TextMuted)
            Text("Method: ${order.paymentMethod}", fontSize = 12.sp, color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.Bold)
            Text("Txn ID: ${order.paymentTxnId}", fontSize = 11.sp, color = TextMuted)
            Text("Items Purchased: ${order.productTitles}", fontSize = 12.sp, color = TextMuted)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Total Paid:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("$${String.format("%.2f", order.amountPaid)}", fontSize = 15.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.secondary)
            }
        }
    }
}

@Composable
fun ProductEditDialog(
    product: Product?,
    onDismiss: () -> Unit,
    onSave: (Product) -> Unit
) {
    var title by remember { mutableStateOf(product?.title ?: "") }
    var description by remember { mutableStateOf(product?.description ?: "") }
    var category by remember { mutableStateOf(product?.category ?: "PLP") }
    var priceStr by remember { mutableStateOf(product?.price?.toString() ?: "4.99") }
    var previewLink by remember { mutableStateOf(product?.previewLink ?: "") }
    var downloadLink by remember { mutableStateOf(product?.downloadLink ?: "") }
    var isNewArrival by remember { mutableStateOf(product?.isNewArrival ?: true) }
    var isFeatured by remember { mutableStateOf(product?.isFeatured ?: false) }

    var inputError by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (product == null) "Add Digital Asset Folder" else "Modify Folder Properties",
                fontWeight = FontWeight.Black
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Asset Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Detailed Description") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Category selection dropdown tags row
                Text("Design Format Category:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("PLP", "PSD", "AI", "Template").forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat) }
                        )
                    }
                }

                OutlinedTextField(
                    value = priceStr,
                    onValueChange = { priceStr = it },
                    label = { Text("Sell Price (USD)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = previewLink,
                    onValueChange = { previewLink = it },
                    label = { Text("Preview Image Link (Unsplash/Imgur)") },
                    singleLine = true,
                    placeholder = { Text("https://images.unsplash.com/...") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = downloadLink,
                    onValueChange = { downloadLink = it },
                    label = { Text("Template Download Link (Google Drive)") },
                    singleLine = true,
                    placeholder = { Text("https://drive.google.com/...") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Toggles
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("New Arrival:", modifier = Modifier.weight(1f))
                    Switch(checked = isNewArrival, onCheckedChange = { isNewArrival = it })
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Featured Item:", modifier = Modifier.weight(1f))
                    Switch(checked = isFeatured, onCheckedChange = { isFeatured = it })
                }

                if (inputError != null) {
                    Text(
                        text = inputError!!,
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val price = priceStr.toDoubleOrNull()
                    if (title.isBlank() || description.isBlank() || price == null) {
                        inputError = "Please satisfy essential title, content & pricing fields!"
                    } else {
                        inputError = null
                        onSave(
                            Product(
                                id = product?.id ?: 0,
                                title = title.trim(),
                                description = description.trim(),
                                category = category,
                                price = price,
                                imageUri = product?.imageUri ?: "img_generic_design",
                                previewLink = previewLink.trim(),
                                downloadLink = downloadLink.trim(),
                                isNewArrival = isNewArrival,
                                isFeatured = isFeatured,
                                rating = product?.rating ?: 4.7f,
                                popularity = product?.popularity ?: 50
                            )
                        )
                    }
                }
            ) {
                Text("Save Changes")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

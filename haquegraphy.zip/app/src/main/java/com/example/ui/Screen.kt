package com.example.ui

sealed class Screen {
    object Home : Screen()
    data class ProductDetail(val productId: Int) : Screen()
    object Cart : Screen()
    object Checkout : Screen()
    object AdminLogin : Screen()
    object AdminDashboard : Screen()
}

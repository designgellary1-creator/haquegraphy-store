package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class MainViewModel(
    private val repository: AppRepository
) : ViewModel() {

    // --- Navigation Back Stack ---
    private val _navigationStack = MutableStateFlow<List<Screen>>(listOf(Screen.Home))
    val currentScreen: StateFlow<Screen> = _navigationStack
        .map { it.lastOrNull() ?: Screen.Home }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), Screen.Home)

    fun navigateTo(screen: Screen) {
        val currentList = _navigationStack.value.toMutableList()
        // Prevent duplicate consecutive screens
        if (currentList.lastOrNull() != screen) {
            currentList.add(screen)
            _navigationStack.value = currentList
        }
    }

    fun navigateBack() {
        val currentList = _navigationStack.value.toMutableList()
        if (currentList.size > 1) {
            currentList.removeAt(currentList.size - 1)
            _navigationStack.value = currentList
        }
    }

    // --- Search & Category Filtering ---
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory = _selectedCategory.asStateFlow()

    private val _sortBy = MutableStateFlow("Popularity") // "Popularity", "Price Low-High", "Price High-Low", "Newest"
    val sortBy = _sortBy.asStateFlow()

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    fun setSortBy(sort: String) {
        _sortBy.value = sort
    }

    // Alias required by StorefrontScreen.kt
    fun setSelectedCategory(category: String) {
        selectCategory(category)
    }

    // --- Products (from SQLite Room) ---
    val products: StateFlow<List<Product>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Alias required by AdminScreen.kt
    val allProducts: StateFlow<List<Product>> = products

    // Filtered lists shown on Grid view
    val filteredProducts: StateFlow<List<Product>> = combine(
        products,
        _searchQuery,
        _selectedCategory,
        _sortBy
    ) { allProds, query, cat, sortOpt ->
        var list = allProds

        // Apply keywords filtration
        if (query.isNotBlank()) {
            list = list.filter {
                it.title.contains(query, ignoreCase = true) ||
                it.description.contains(query, ignoreCase = true)
            }
        }

        // Apply format categorizations
        if (cat != "All") {
            list = list.filter { it.category.equals(cat, ignoreCase = true) }
        }

        // Sort items
        when (sortOpt) {
            "Popularity" -> list = list.sortedByDescending { it.popularity }
            "Price Low-High" -> list = list.sortedBy { it.price }
            "Price High-Low" -> list = list.sortedByDescending { it.price }
            "Newest" -> list = list.sortedByDescending { it.isNewArrival }
            else -> list = list.sortedByDescending { it.id }
        }

        list
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Product Detail Core ---
    private val _activeProductId = MutableStateFlow<Int?>(null)
    val activeProductDetail: StateFlow<Product?> = combine(
        products,
        _activeProductId
    ) { allProds, targetId ->
        if (targetId == null) null else allProds.find { it.id == targetId }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun viewProductDetail(productId: Int) {
        _activeProductId.value = productId
        navigateTo(Screen.ProductDetail(productId))
    }

    // --- Cart System (Dynamic Mapping with Database) ---
    val cartItems: Flow<List<CartItem>> = repository.allCartItems

    val cartProducts: StateFlow<List<CartProduct>> = combine(
        products,
        cartItems
    ) { allProds, cartDetails ->
        cartDetails.mapNotNull { details ->
            val product = allProds.find { it.id == details.productId }
            if (product != null) CartProduct(product, details.quantity) else null
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Perfect Map for StorefrontScreen Pair expectation
    val cartWithDetails: StateFlow<List<Pair<Product, Int>>> = combine(
        products,
        cartItems
    ) { allProds, cartDetails ->
        cartDetails.mapNotNull { details ->
            val product = allProds.find { it.id == details.productId }
            if (product != null) Pair(product, details.quantity) else null
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cartTotalPrice: StateFlow<Double> = cartProducts.map { list ->
        list.sumOf { it.product.price * it.quantity }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Alias required by StorefrontScreen.kt
    val cartTotalAmount: StateFlow<Double> = cartTotalPrice

    val cartTotalCount: StateFlow<Int> = cartProducts.map { list ->
        list.sumOf { it.quantity }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    fun addToCart(productId: Int) {
        viewModelScope.launch {
            val currentCart = cartProducts.value
            val existing = currentCart.find { it.product.id == productId }
            if (existing != null) {
                repository.updateCartItem(CartItem(productId, existing.quantity + 1))
            } else {
                repository.insertCartItem(CartItem(productId, 1))
            }
        }
    }

    fun addToCart(product: Product) {
        addToCart(product.id)
    }

    fun updateCartQuantity(productId: Int, quantity: Int) {
        viewModelScope.launch {
            if (quantity <= 0) {
                repository.deleteCartItemByProductId(productId)
            } else {
                repository.updateCartItem(CartItem(productId, quantity))
            }
        }
    }

    fun removeFromCart(productId: Int) {
        viewModelScope.launch {
            repository.deleteCartItemByProductId(productId)
        }
    }

    fun checkCartContains(productId: Int): Flow<Boolean> {
        return cartItems.map { items ->
            items.any { it.productId == productId }
        }
    }

    // --- Checkout & Simulated Orders Core ---
    private val _lastPlacedOrder = MutableStateFlow<Order?>(null)
    val lastPlacedOrder = _lastPlacedOrder.asStateFlow()

    // Alias required by StorefrontScreen.kt
    val checkoutSuccessOrder: StateFlow<Order?> = lastPlacedOrder

    val orders: StateFlow<List<Order>> = repository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Alias required by AdminScreen.kt
    val allOrders: StateFlow<List<Order>> = orders

    fun clearLastPlacedOrder() {
        _lastPlacedOrder.value = null
    }

    // Alias required by StorefrontScreen.kt
    fun dismissSuccessOrder() {
        clearLastPlacedOrder()
    }

    fun placeOrder(
        customerName: String,
        customerEmail: String,
        customerPhone: String,
        paymentMethod: String,
        txnId: String,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            val total = cartTotalPrice.value
            val items = cartProducts.value

            val productIdsStr = items.map { it.product.id }.joinToString(",")
            val productTitlesStr = items.map { "${it.product.title} (x${it.quantity})" }.joinToString(", ")

            val orderIdHex = "HQ-${(1000..9999).random()}"
            val finalTxn = if (paymentMethod == "COD" || paymentMethod.contains("Cash Off Delivery", ignoreCase = true) || paymentMethod.contains("Delivery", ignoreCase = true)) {
                "COD-${UUID.randomUUID().toString().take(6).uppercase()}"
            } else {
                txnId.ifBlank { "MOCK-${UUID.randomUUID().toString().take(6).uppercase()}" }
            }

            val order = Order(
                id = orderIdHex,
                customerName = customerName,
                customerEmail = customerEmail,
                customerPhone = customerPhone,
                paymentMethod = paymentMethod,
                paymentTxnId = finalTxn,
                amountPaid = total,
                productIds = productIdsStr,
                productTitles = productTitlesStr,
                status = "Completed"
            )

            repository.insertOrder(order)
            repository.clearCart()
            _lastPlacedOrder.value = order
            navigateTo(Screen.Home) // Navigate back to principal catalog after checkout
            onSuccess()
        }
    }

    // --- Admin Authentication Panel ---
    private val _isAdminAuthenticated = MutableStateFlow(false)
    val isAdminAuthenticated = _isAdminAuthenticated.asStateFlow()

    // Aliases required by AdminScreen.kt
    val isAdminLoggedIn: StateFlow<Boolean> = isAdminAuthenticated

    private val _adminLoginError = MutableStateFlow<String?>(null)
    val adminLoginError = _adminLoginError.asStateFlow()

    // Alias required by AdminScreen.kt
    val currentAdminError: StateFlow<String?> = adminLoginError

    private val _adminLoginLoading = MutableStateFlow(false)
    val adminLoginLoading = _adminLoginLoading.asStateFlow()

    fun loginAdmin(username: String, password: String) {
        val trimmedUser = username.trim()
        val email = if (trimmedUser.contains("@")) trimmedUser else "haquegraphy@example.com"

        _adminLoginLoading.value = true
        _adminLoginError.value = null

        try {
            val auth = com.google.firebase.auth.FirebaseAuth.getInstance()
            auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener { task ->
                    _adminLoginLoading.value = false
                    if (task.isSuccessful) {
                        _isAdminAuthenticated.value = true
                        _adminLoginError.value = null
                        navigateTo(Screen.AdminDashboard)
                    } else {
                        // Firebase could not log in (unregistered email / wrong pass / offline context).
                        // Fall back to pre-defined credential check to ensure absolute 100% reliability of the applet!
                        val localUsernameSuccess = trimmedUser.equals("HAQUEGRAPHY", ignoreCase = true)
                        val localPasswordSuccess = password == "123456"

                        if (localUsernameSuccess && localPasswordSuccess) {
                            _isAdminAuthenticated.value = true
                            _adminLoginError.value = null
                            navigateTo(Screen.AdminDashboard)
                        } else {
                            val originalError = task.exception?.localizedMessage ?: "Unknown Error"
                            _adminLoginError.value = "Credential verification failed. (Local Match: Blocked / Firebase Error: $originalError)"
                        }
                    }
                }
        } catch (e: Exception) {
            _adminLoginLoading.value = false
            // Catching any uninitialized Firebase exceptions and performing direct pre-defined validation fallback
            val localUsernameSuccess = trimmedUser.equals("HAQUEGRAPHY", ignoreCase = true)
            val localPasswordSuccess = password == "123456"

            if (localUsernameSuccess && localPasswordSuccess) {
                _isAdminAuthenticated.value = true
                _adminLoginError.value = null
                navigateTo(Screen.AdminDashboard)
            } else {
                _adminLoginError.value = "System Error: ${e.localizedMessage ?: "Invalid Username or Password."}"
            }
        }
    }

    // Alias required by AdminScreen.kt
    fun attemptAdminLogin(username: String, password: String) {
        loginAdmin(username, password)
    }

    fun logoutAdmin() {
        try {
            com.google.firebase.auth.FirebaseAuth.getInstance().signOut()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        _isAdminAuthenticated.value = false
        _navigationStack.value = listOf(Screen.Home)
    }

    // Alias required by AdminScreen.kt
    fun adminLogout() {
        logoutAdmin()
    }

    // --- Admin CRUD Panel Functions ---
    val editingProduct = MutableStateFlow<Product?>(null)

    fun startEditingProduct(productId: Int) {
        viewModelScope.launch {
            val prod = repository.getProductById(productId)
            editingProduct.value = prod
        }
    }

    fun clearEditingProduct() {
        editingProduct.value = null
    }

    fun adminDeleteProduct(productId: Int) {
        viewModelScope.launch {
            repository.deleteProductById(productId)
            if (_activeProductId.value == productId) {
                _activeProductId.value = null
            }
        }
    }

    // Alias required by AdminScreen.kt
    fun deleteProduct(product: Product) {
        adminDeleteProduct(product.id)
    }

    // Unified Admin Save function handles both insertion and update
    fun saveProduct(
        id: Int,
        title: String,
        description: String,
        category: String,
        price: Double,
        imageUri: String,
        previewLink: String,
        downloadLink: String,
        popularity: Int,
        isNewArrival: Boolean,
        isFeatured: Boolean
    ) {
        viewModelScope.launch {
            val placeholderUrl = when (category.uppercase()) {
                "PLP" -> "https://images.unsplash.com/photo-1542831371-29b0f74f9713?q=80&w=800"
                "PSD" -> "https://images.unsplash.com/photo-1483985988355-763728e1935b?q=80&w=800"
                "AI" -> "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?q=80&w=800"
                else -> "https://images.unsplash.com/photo-1586281380349-632531db7ed4?q=80&w=800"
            }
            val finalImg = imageUri.ifBlank { "placeholder" }
            val finalPreview = previewLink.ifBlank { placeholderUrl }
            val finalDownload = downloadLink.ifBlank { "https://haquegraphy.com/deliverable_mock_payload" }

            if (id == 0) {
                val newProduct = Product(
                    title = title,
                    description = description,
                    category = category,
                    price = price,
                    imageUri = finalImg,
                    previewLink = finalPreview,
                    downloadLink = finalDownload,
                    rating = 4.8f,
                    popularity = if (popularity > 0) popularity else (30..150).random(),
                    isNewArrival = isNewArrival,
                    isFeatured = isFeatured
                )
                repository.insertProduct(newProduct)
            } else {
                val updatedProduct = Product(
                    id = id,
                    title = title,
                    description = description,
                    category = category,
                    price = price,
                    imageUri = finalImg,
                    previewLink = finalPreview,
                    downloadLink = finalDownload,
                    rating = 4.8f,
                    popularity = popularity,
                    isNewArrival = isNewArrival,
                    isFeatured = isFeatured
                )
                repository.updateProduct(updatedProduct)
            }
        }
    }

    fun adminAddProduct(
        title: String,
        description: String,
        category: String,
        price: Double,
        imageUriStr: String,
        previewLink: String,
        downloadLink: String,
        isNew: Boolean,
        isFeat: Boolean
    ) {
        saveProduct(
            id = 0,
            title = title,
            description = description,
            category = category,
            price = price,
            imageUri = imageUriStr,
            previewLink = previewLink,
            downloadLink = downloadLink,
            popularity = 100,
            isNewArrival = isNew,
            isFeatured = isFeat
        )
    }

    fun adminUpdateProduct(product: Product) {
        viewModelScope.launch {
            repository.updateProduct(product)
        }
    }
}

class MainViewModelFactory(
    private val repository: AppRepository
) : ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MainViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

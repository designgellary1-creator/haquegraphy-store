package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// --- High Density Style Color Palette (SaaS & Creative Market Aesthetic) ---

// Dark Mode Elements
val BrandAccentNeon = Color(0xFF6366F1) // Indigo 500 (premium neon accent)
val BrandSecondaryNeon = Color(0xFF818CF8) // Indigo 400
val AccentOrange = Color(0xFFF97316) // Vibrant Orange
val DarkBg = Color(0xFF0F172A) // Slate 900 (deep cosmic slate)
val DarkSurface = Color(0xFF1E293B) // Slate 800 (clean elevated card base)
val DarkSurfaceCard = Color(0xFF334155) // Slate 700 (high density containers)
val TextLight = Color(0xFFF8FAFC) // Slate 50

// Light Mode Elements (Matches High Density HTML design template)
val BrandAccentLight = Color(0xFF4F46E5) // Indigo 600
val BrandSecondaryLight = Color(0xFF4338CA) // Indigo 700
val LightBg = Color(0xFFF3F4F9) // Clean slate light grey
val LightSurface = Color(0xFFFFFFFF) // Crisp pure white

// Common branding colors
val SuccessGreen = Color(0xFF10B981) // Emerald status green
val NagadOrange = Color(0xFFF7941D) // Nagad Brand Color
val BkashPink = Color(0xFFE2125D) // bKash Brand Color
val RocketPurple = Color(0xFF8C3494) // Rocket Brand Color
val RealWhite = Color(0xFFFFFFFF)
val Slate500 = Color(0xFF64748B)
val Slate900 = Color(0xFF0F172A)
val TextMuted = Color(0xFF64748B)


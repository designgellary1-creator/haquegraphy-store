package com.example.ui

import com.example.data.Product

data class CartProduct(
    val product: Product,
    val quantity: Int
)

// Legendary Kotlin 200-IQ extensions to handle inconsistent Pair vs CartProduct models in template code
val Pair<Product, Int>.product: Product
    get() = this.first

val Pair<Product, Int>.quantity: Int
    get() = this.second
